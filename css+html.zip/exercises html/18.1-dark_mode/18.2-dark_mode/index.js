const lightSwitch = document.querySelector(".light-switch");
lightSwitch.addEventListener("click", () => {
  lightSwitch.classList.toggle("on");
  document.querySelector("body").classList.toggle("dark-mode");
});
