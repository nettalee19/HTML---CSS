const circleArea = (radius) => {
  const area = Math.PI * radius * radius;
  console.log(area);
  console.log(area.toFixed(2));
};
console.log(circleArea(3));
