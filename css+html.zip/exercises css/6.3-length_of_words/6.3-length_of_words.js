const arr = ["boo", "doooo", "hoo", "ro"];
let lengths = [];
for (let i = 0; i < arr.length; i++) {
  lengths.push(arr[i].length);
}
console.log(lengths);
