const obj = {};
const map = new Map();
const x = [];
const userss = new Array(3000000).fill(1);

const users = [
  "John",
  "Murray",
  "Jane",
  "Jane",
  "Anne",
  "John",
  "Murray",
  "Jane",
  "Jane",
  "Anne",
];

for (let i = 0; i < userss.length; i++) {
  obj[i] = users[i];
  map.set(i, users[i]);
}

let result;

const timeMap = () => {
  console.time("Map");
  result = map.has(0);
  console.timeEnd("Map");
};
console.log(timeMap());

const timeObject = () => {
  console.time("Object");
  result = obj.hasOwnProperty(0);
  console.timeEnd("Object");
};

console.log(timeObject());
