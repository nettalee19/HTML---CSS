function steps1(n) {
  x = 1;
  for (let i = 0; i < n; i++) {
    if ("#".repeat(x).length == 3) {
      console.log("#".repeat(x));
    } else {
      console.log("#".repeat(x) + " ".repeat(n - "#".repeat(x).length));
    }
    x++;
  }
}

function steps2(n) {
  for (let row = 0; row < n; row++) {
    let stair = "";
    for (let column = 0; column < n; column++) {
      if (row >= column) {
        stair += "#";
      } else {
        stair += " ";
      }
    }
    console.log(stair);
  }
}
