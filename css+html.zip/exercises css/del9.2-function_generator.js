const randomNumber = () => {
  return Math.floor(Math.random() * 20) + 1;
};

const findMyNumber = (number, callback) => {
  let counter = 0;
  while (number !== callback()) {
    counter++;
  }
  return console.log(`it took ${counter} times to find your number`);
};

console.log(findMyNumber(5, randomNumber));
