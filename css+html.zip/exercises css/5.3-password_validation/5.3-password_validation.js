const passwordValidator = (password) => {
  if (password.length > 7) {
    ("Strong");
  } else {
    ("Weak");
  }
};

const passwordValidator2 = (password) => {
  return password.length > 7 ? "Strong" : "Weak";
};

const passwordValidator3 = (password) => {
  return (password.length > 7 && "Strong") || "Weak";
};

const passwordValidator4 = (password) => {
  return password.length > 7 && /[A-Z]/.test(password)
    ? "Very Strong"
    : password.length > 7
    ? "Strong"
    : "Weak";
};
console.log(passwordValidator4("aA"));
