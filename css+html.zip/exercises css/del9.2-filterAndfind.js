const users = [
  {
    id: 1,
    firstName: "Jimmy",
    lastName: "Johnson",
    email: "jimmy@hotmail.com",
  },
  {
    id: 2,
    firstName: "Harry",
    lastName: "King",
    email: "harry@hotmail.com",
  },
  {
    id: 3,
    firstName: "Timmy",
    lastName: "Southern",
    email: "timmy@hotmail.com",
  },
  {
    id: 4,
    firstName: "Martha",
    lastName: "Benedict",
    email: "martha@hotmail.com",
  },
];
const findById = (id, callback) => {
  return (user) => {
    const user =
  };
};

const getFullName = (user) => {
  console.log(user);
  return `${user.firstName} ${user.lastName}`;
};

const user = users.find(findById(1, getFullName));
console.log(user);
