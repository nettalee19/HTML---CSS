const people = ["Greg", "Mary", "Devon", "James"];
// console.log(people.slice(-1)[0]);
// console.log(people[people.length - 1]);
// 1
for (let i = 0; i < people.length; i++) {
  // console.log(people[i]);
}

// 2

people.shift();

// 3

people.pop();

// 4

people.unshift("Matt");

// 5

people.push("Ellie");

// 6

for (var i = 0; i < people.length; i++) {
  const index = people.indexOf("Mary");

  if (i > index) {
    break;
  }
  // console.log(people[i]);
}

// 7
// console.log(people);
console.log(people.slice(2));

// 8

people.indexOf("Mary");

// 9

people.indexOf("Foo");

// 10

const people2 = ["Greg", "Mary", "Devon", "James"];

people2.splice(2, 1, "Elizabeth", "Artie");

// 11

const withBob = people2.concat("Bob");
const withBob2 = [...people2, "Bob"];
console.log(withBob2);
console.log(people2);
