const numSiblings = Number(prompt("How many siblings do you have?"));

if (numSiblings === 1) {
  console.log("Only 1 sibling");
} else if (numSiblings > 1) {
  console.log("More than 1 Sibling");
} else {
  console.log("No Siblings");
}
