//create 3 objects that have a key name and value to it and store them to seperate variables
let userIDs = new Map();

let user1 = { name: "John" },
  user2 = { name: "Murray" },
  user3 = { name: "Jane" };

//create a new map that takes the objects as the key and assign an id number as the value
userIDs.set(user1, 1).set(user2, 2).set(user3, 3);

// Method 1
//iterate over map object with for..of and console log the name and id
for (let [name, id] of userIDs) {
  console.log(name);
  console.log(id);
}

//Method 2
//iterate over the map object with forEach. and console log the name and id
userIDs.forEach((value, key) => {
  console.log("name:", key);
  console.log("key:", value);
});
