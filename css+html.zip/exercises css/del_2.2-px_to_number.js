const px = "30px";
console.log(parseInt(px));
